package com.afa1997.jobs_board.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.thymeleaf.extras.springsecurity5.dialect.SpringSecurityDialect;

// It's possible to create multiple log-in screens for different kinds of users, see this for more information: < https://www.yawintutor.com/multiple-login-pages-using-spring-boot-security/ >. They work with JSP for the templates, but it's easily appliable to Thymeleaf.
@Configuration
@Order(2)
public class UserSecurityConfiguration extends WebSecurityConfigurerAdapter {
	private static final String[] AUTH_LIST = {
		"/jobs"
	};

	// Part of user logged in status check, see: https://stackoverflow.com/questions/28904176/thymeleaf-with-spring-security-how-to-check-if-user-is-logged-in-or-not
    @Bean
    public SpringSecurityDialect secDialUser(){
        return new SpringSecurityDialect();
    }
	
	// External resource files aren't loaded by default with Spring Security, but this method will prevent that issue. Code based on solution by Athena, at: < https://stackoverflow.com/questions/41910004/add-css-file-to-spring-boot-spring-security-thymeleaf-file >
	@Override
	public void configure(WebSecurity web) throws Exception{
		web.ignoring().antMatchers("/css/**","/extras/**","/fonts/**","/js/**","/user_uploads/**");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http.csrf().disable().authorizeRequests()
		.antMatchers(AUTH_LIST).hasRole("USER")
		.anyRequest().authenticated()
		.and().formLogin().loginPage("/user/login").defaultSuccessUrl("/",true).permitAll()
		.and().logout().logoutRequestMatcher(new AntPathRequestMatcher("/user/logout"));
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		auth.inMemoryAuthentication()
		.withUser("user").password("{noop}password").roles("USER");
	}
}
