package com.afa1997.jobs_board.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.thymeleaf.extras.springsecurity5.dialect.SpringSecurityDialect;

@Configuration
@Order(1)
public class CompanySecurityConfiguration extends WebSecurityConfigurerAdapter {
	private static final String[] AUTH_LIST = {
			"/user/profile/{uid}"
		};

	    @Bean
	    public SpringSecurityDialect secDialComp(){
	        return new SpringSecurityDialect();
	    }
		
		@Override
		public void configure(WebSecurity web) throws Exception{
			web.ignoring().antMatchers("/css/**","/extras/**","/fonts/**","/js/**","/user_uploads/**");
		}

		@Override
		protected void configure(HttpSecurity http) throws Exception{
			http.csrf().disable().authorizeRequests()
			.antMatchers(AUTH_LIST).hasRole("COMPANY")
			.anyRequest().authenticated()
			.and().formLogin().loginPage("/companies/login").defaultSuccessUrl("/",true).permitAll()
			.and().logout().logoutRequestMatcher(new AntPathRequestMatcher("/companies/logout"));
		}

		@Override
		protected void configure(AuthenticationManagerBuilder auth) throws Exception{
			auth.inMemoryAuthentication()
			.withUser("1").password("{noop}password").roles("COMPANY");
		}
}
